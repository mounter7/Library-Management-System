
import java.sql.Connection;
import java.sql.DriverManager;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author root
 */

public class DbConnect {
    public static Connection connect(){
    
    Connection conn=null;
    
        try {
            Class.forName("com.mysql.jdbc.Driver");
           conn=(Connection) DriverManager.getConnection("jdbc:mysql://sql6.freemysqlhosting.net:3306/sql6464172", "sql6464172", "Qbn7vrwdVI");
            
        } catch (Exception e) {
            NewJFrame4 cf=new NewJFrame4();
           // cf.setVisible(true);
            
            
        }
    
    return conn;
    
    }
}